package com.sraljb.rahulsathputhe.meetutu;

/**
 * Created by Rahul Sathputhe on 03-09-2016.
 */
public class NewActivity {
    GoogleMap googleMap;
    googleMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();

}
